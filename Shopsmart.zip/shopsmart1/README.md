# ShopSmart1
This is the full stack grocery store project.